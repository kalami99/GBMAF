import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler, LabelEncoder
import os

# 设置数据路径
data_path = r"D:\多粒度计算\代码\TWO_new\dataset"
os.chdir(data_path)

print("=" * 60)
print("处理 abalone.csv：标签分3类 + 归一化")
print("=" * 60)

# ============================================================
# 读取数据
# ============================================================
df = pd.read_csv('abalone.csv', header=None)

# 分离特征和标签（最后一列是Rings标签）
X_abalone = df.iloc[:, :-1]   # 前8列是特征
y_abalone = df.iloc[:, -1]    # 最后一列是标签 (Rings)

print(f"  原始形状: {df.shape}")
print(f"  原始标签类别数: {len(y_abalone.unique())}")
print(f"  原始标签范围: {y_abalone.min()} ~ {y_abalone.max()}")

# ============================================================
# 将 Rings 分为 3 类
# ============================================================
# 方法1：基于分位数（等频划分）
# 类别0：幼年（低环数），类别1：成年（中环数），类别2：老年（高环数）
q1 = y_abalone.quantile(0.33)
q2 = y_abalone.quantile(0.67)

def map_rings_to_class(ring):
    if ring <= q1:
        return 0   # 幼年
    elif ring <= q2:
        return 1   # 成年
    else:
        return 2   # 老年

y_abalone_binned = y_abalone.apply(map_rings_to_class).values

print(f"  Rings 分位数: Q1={q1:.1f}, Q2={q2:.1f}")
print(f"  类别0 (幼年) 数量: {np.sum(y_abalone_binned == 0)}")
print(f"  类别1 (成年) 数量: {np.sum(y_abalone_binned == 1)}")
print(f"  类别2 (老年) 数量: {np.sum(y_abalone_binned == 2)}")

# ============================================================
# 对 Sex 特征编码 + 归一化
# ============================================================
# 对 Sex 特征（第1列）编码：M/F/I → 0/1/2
le = LabelEncoder()
sex_encoded = le.fit_transform(X_abalone.iloc[:, 0].astype(str))

# 重建特征矩阵
X_abalone_rebuilt = np.column_stack([
    sex_encoded,
    X_abalone.iloc[:, 1:].values.astype(float)
])

print(f"  Sex编码: M={le.transform(['M'])[0]}, F={le.transform(['F'])[0]}, I={le.transform(['I'])[0]}")

# 归一化特征
scaler = StandardScaler()
X_abalone_scaled = scaler.fit_transform(X_abalone_rebuilt)

# ============================================================
# 保存处理后的数据（标签在第一列）
# ============================================================
df_processed = pd.DataFrame(X_abalone_scaled)
df_processed.insert(0, 'label', y_abalone_binned)  # 标签放在第一列
df_processed.to_csv('abalone.csv', header=False, index=False)

print(f"  已保存: abalone.csv（标签已分为3类，特征已归一化）")

# ============================================================
# 验证
# ============================================================
print("\n【验证】")
df_check = pd.read_csv('abalone.csv', header=None)
print(f"  形状: {df_check.shape}")
print(f"  第1列(标签)取值: {sorted(df_check.iloc[:, 0].unique())}")
print(f"  第1列(标签)分布: {df_check.iloc[:, 0].value_counts().sort_index().tolist()}")

print("\n" + "=" * 60)
print("处理完成！")
print("=" * 60)